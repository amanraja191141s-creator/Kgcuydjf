# Release v100.10 — Remove duplicated nested field layers

- Corrected the actual screenshot defect: nested editable `.input-val-box` controls were rendering a second card/border inside their parent field rows.
- Applied a shared transparent inner-control treatment across tool field wrappers.
- Rebuilt Loan form rows as single outlined controls with label and value inside one frame; removed overlapping/oversized nested boxes.
- Preserved numeric keypad, input editing, Months/Years controls, tenure picker behavior, calculation engine, and all 12 tool screens.
- Preserved ZIP extraction, Android SDK/Gradle build, APK verification, and absolute-path artifact upload workflow.
- Android version: `2.0.8-v100.10`; versionCode: `1099149`.
