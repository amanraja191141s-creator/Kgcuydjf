# SA Calculator Tools Only v100.12

- Reworked every tool input wrapper to use the Loan screen as the single visual reference.
- Standardized field minimum height (76px), 10px radius, 15px horizontal padding, 16px spacing, 14px labels and 18px values.
- Removed nested input borders, backgrounds and shadows so each input has one outer frame.
- Preserved functional horizontal compound controls for Currency, Unit and BMI.
- Preserved existing IDs, data-target bindings, calculation logic, picker/radio/select behavior, result panels and shared keypad.
- Bumped app/service-worker version to prevent stale Android web assets.
- Preserved ZIP extraction and APK artifact upload workflow.
