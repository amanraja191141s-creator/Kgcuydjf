import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('Android workflow avoids removed sdkmanager tools package', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  assert.doesNotMatch(yml, /android-actions\/setup-android@/);
  assert.doesNotMatch(yml, /sdkmanager\s+tools(?:\s|$)/);
  assert.match(yml, /platform-tools/);
  assert.match(yml, /platforms;android-35/);
  assert.match(yml, /build-tools;35\.0\.0/);
  assert.match(yml, /dump badging/);
});

test('Node setup does not require a missing npm lockfile for dependency caching', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  const nodeStep = yml.split('- name: Set up Node.js 22')[1]?.split('- name:')[0] ?? '';
  assert.match(nodeStep, /node-version:\s*22/);
  assert.doesNotMatch(nodeStep, /^\s*cache:/m);
  assert.doesNotMatch(nodeStep, /cache-dependency-path:/);
  assert.match(nodeStep, /package-manager-cache:\s*false/);
  assert.match(yml, /actions\/checkout@v7/);
  assert.match(yml, /actions\/setup-node@v7/);
  assert.match(yml, /actions\/setup-java@v5/);
  assert.match(yml, /actions\/upload-artifact@v7/);
  assert.match(yml, /npm install --no-package-lock/);
});


test('workflow discovers the app root when repository files are nested in an extracted project folder', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  assert.match(yml, /locate project root/i);
  assert.match(yml, /WORKSPACE=\"\$GITHUB_WORKSPACE\"/);
  assert.match(yml, /PROJECT_DIR/);
  assert.match(yml, /working-directory:\s*\$\{\{ env\.PROJECT_DIR \}\}/);
  assert.match(yml, /package\.json/);
});


test('workflow extracts the uploaded project ZIP before resolving the app root', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  assert.match(yml, /Extract uploaded project ZIP and locate project root/);
  assert.match(yml, /SA-Calculator-Tools-Only\*\.zip/);
  assert.match(yml, /sort -z -V/);
  assert.match(yml, /archives=\(\"\$\{archives\[-1\]\}\"\)/);
  assert.match(yml, /unzip -q/);
  assert.match(yml, /RUNNER_TEMP\/sa-calculator-source/);
  assert.match(yml, /after archive extraction/);
});


test('APK artifact upload uses the verified absolute path from the extracted project root', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  const verifyStep = yml.split('- name: Verify APK and package metadata')[1]?.split('- name: Upload installable debug APK')[0] ?? '';
  const uploadStep = yml.split('- name: Upload installable debug APK')[1] ?? '';
  assert.match(verifyStep, /APK_PATH=\$PROJECT_DIR\/\$APK/);
  assert.match(verifyStep, /test -s "\$PROJECT_DIR\/\$APK"/);
  assert.match(uploadStep, /path:\s*\$\{\{ env\.APK_PATH \}\}/);
  assert.doesNotMatch(uploadStep, /path:\s*android\//);
});
