import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(p)=>fs.readFileSync(new URL(`../${p}`,import.meta.url),'utf8');
test('all 12 tool screens retain the reference recording compact field system',()=>{
 const html=read('index.html'); const css=read('assets/css/tool-reference-ui.css');
 const screens=['currencies','units','discount','percent','salestax','agecalc','bodymetrics','loan','salary','savings','sip','tip'];
 for(const id of screens) assert.match(html,new RegExp(`id="screen-${id}"`),`missing tool screen ${id}`);
 assert.match(css,/min-height:52px !important/); assert.match(css,/height:52px !important/);
 assert.doesNotMatch(css,/min-height:76px !important/);
});
test('nested editable values cannot render a second outline or surface',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 const start=css.lastIndexOf('v100.13 — restore the reference recording'); const layer=css.slice(start);
 assert.ok(start>0); assert.match(layer,/\.input-val-box[\s\S]*?border:0 !important/);
 assert.match(layer,/background:transparent !important/); assert.match(layer,/box-shadow:none !important/);
});
test('Loan, currency, unit and BMI preserve their distinct functional arrangements',()=>{
 const html=read('index.html'); const css=read('assets/css/tool-reference-ui.css');
 assert.match(html,/name="loan-tenure-unit" type="radio" value="months"/);
 assert.match(html,/name="loan-tenure-unit" type="radio" value="years"/);
 assert.match(html,/id="cur-from"/); assert.match(html,/id="unit-from"/); assert.match(html,/id="bmi-weight"/);
 assert.match(css,/#screen-currencies \.tool-field-row[\s\S]*?flex-direction:row/);
});
test('production stylesheet mirrors source and is loaded',()=>{
 assert.equal(read('www/assets/css/tool-reference-ui.css'),read('assets/css/tool-reference-ui.css'));
 assert.match(read('index.html'),/assets\/css\/tool-reference-ui\.css/);
});
